<?php 
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$isAdmin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
$isUser  = isset($_SESSION['role']) && $_SESSION['role'] === 'user';

$conn = new mysqli("localhost", "u498346438_calculrem", "Calculrem1", "u498346438_calculrem");
if ($conn->connect_error) { die("Erreur de connexion : " . $conn->connect_error); }

// ---- Pagination
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 30;
$allowed = [10,30,50,100,200];
if (!in_array($limit, $allowed, true)) { $limit = 30; }
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// ---- Suppression multiple (admin uniquement)
if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_selected']) && !empty($_POST['selected_ids'])) {
    foreach ($_POST['selected_ids'] as $id) {
        $id = (int)$id;
        if ($stmtDel = $conn->prepare("DELETE FROM historiques WHERE id=?")) {
            $stmtDel->bind_param("i", $id);
            $stmtDel->execute();
            $stmtDel->close();
        }
    }
    $conn->query("ALTER TABLE historiques AUTO_INCREMENT = 1");
    $success = "✅ Devis sélectionnés supprimés et compteur réinitialisé.";
}

// ---- Filtre devis
$filterWhere = "(statut IS NULL OR statut = '' OR statut = 'ticket' OR statut = 'devis')";

// ---- Total
$qCount = $conn->query("SELECT COUNT(*) AS c FROM historiques WHERE $filterWhere");
$total = (int)($qCount ? $qCount->fetch_assoc()['c'] : 0);
$total_pages = max(1, (int)ceil($total / $limit));

// ---- Liste paginée
$sql = "SELECT id, date_enregistrement, client_nom, client_tel, piece, ref_piece, fournisseur, quantite, prix_final, IFNULL(statut,'devis') AS statut
        FROM historiques
        WHERE $filterWhere
        ORDER BY id DESC
        LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $limit, $offset);
$stmt->execute();
$result = $stmt->get_result();
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Historique des Devis</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg,#0a1f44,#1d5fa7,#3ba9ff); min-height:100vh; color:#fff; }
.card.glass { background:rgba(255,255,255,0.1); border:1px solid rgba(255,255,255,0.2); backdrop-filter:blur(10px); border-radius:16px; }
table td, table th { vertical-align:middle; color:#000!important; font-weight:bold; background:#fff; border:1px solid #ccc; }
table thead th { background:#2e7d32!important; color:#fff!important; }
.badge-light { background:#eee; color:#333; font-weight:600; }
</style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="container py-4">
  <form method="post">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h2 class="m-0">📜 Historique des Devis</h2>
      <?php if ($isAdmin): ?>
        <button type="submit" name="delete_selected" class="btn btn-danger" onclick="return confirm('Confirmer la suppression des devis sélectionnés ?')">
          🗑 Supprimer la sélection
        </button>
      <?php endif; ?>
    </div>

    <div class="card glass shadow-lg p-3">
      <div class="table-responsive">
        <table class="table table-hover align-middle">
<thead>
  <tr>
    <th style="width:36px;">
      <?php if ($isAdmin): ?>
        <input type="checkbox" id="select-all">
      <?php endif; ?>
    </th>
    <th>ID</th>
    <th>Statut</th>
    <th>Date</th>
    <th>Client</th>
    <th>Téléphone</th>
    <th>Pièce</th>
    <th>Réf. Fournisseur</th>
    <th>Fournisseur</th>
    <th>Quantité</th>
    <th>Prix TTC</th>
    <th>Actions</th>
  </tr>
</thead>
<tbody>
  <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
      <td>
        <?php if ($isAdmin): ?>
          <input type="checkbox" name="selected_ids[]" value="<?= (int)$row['id'] ?>">
        <?php endif; ?>
      </td>
      <td><?= (int)$row['id'] ?></td>
      <td><span class="badge badge-light"><?= htmlspecialchars($row['statut']) ?></span></td>
      <td><?= htmlspecialchars($row['date_enregistrement']) ?></td>
      <td><?= htmlspecialchars($row['client_nom']) ?></td>
      <td><?= htmlspecialchars($row['client_tel']) ?></td>
      <td><?= htmlspecialchars($row['piece']) ?></td>
      <td><?= htmlspecialchars($row['ref_piece']) ?></td>
      <td><?= htmlspecialchars($row['fournisseur']) ?></td>
      <td><?= (int)$row['quantite'] ?></td>
      <td><?= number_format((float)$row['prix_final'],2) ?> €</td>
      <td>
        <a href="telecharger_ticket.php?id=<?= (int)$row['id'] ?>" target="_blank" class="btn btn-sm btn-warning">📄</a>
        <!-- ✅ Tous (admin + user) peuvent accepter -->
        <a href="valider_commande.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-success">✅</a>
      </td>
    </tr>
  <?php endwhile; $stmt->close(); ?>
</tbody>

        </table>
      </div>
    </div>
  </form>
</div>
<script>
const selectAll=document.getElementById('select-all');
if(selectAll){
  selectAll.addEventListener('click',()=>{
    document.querySelectorAll('input[name="selected_ids[]"]').forEach(cb=>cb.checked=selectAll.checked);
  });
}
</script>
</body>
</html>
