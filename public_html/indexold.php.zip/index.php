
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>CALCUL PRIX R.E.MOBILES</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <img src="logo-rem.png" alt="Logo REM" class="logo">
        <h1>CALCUL PRIX R.E.MOBILES</h1>
    </header>

    <div class="container">
        <form action="generate_pdf.php" method="POST" target="_blank">
            <label>Nom de la pièce :
                <input type="text" name="piece" required>
            </label>
            <label>Prix d'achat unitaire (€) :
                <input type="number" step="0.01" name="prixAchat" required>
            </label>
            <label>Quantité :
                <input type="number" name="quantite" required>
            </label>
            <label>Coût main d'œuvre (€) :
                <input type="number" step="0.01" name="mainOeuvre" required>
            </label>
            <label>Nom du client :
                <input type="text" name="clientNom" required>
            </label>
            <label>Téléphone du client :
                <input type="text" name="clientTel" required>
            </label>
            <label>Type de document :
                <select name="docType">
                    <option value="DEVIS">DEVIS</option>
                    <option value="PROFORMA">PROFORMA</option>
                    <option value="FACTURE">FACTURE</option>
                </select>
            </label>
            <button type="submit">Générer le PDF</button>
        </form>
    </div>
</body>
</html>
