<?php 
session_start(); 

// --- Vérification de session --- 
if (!isset($_SESSION['user_id'])) { 
    header("Location: login.php"); 
    exit; 
} 

$isAdmin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin'; 

// --- Connexion à la base de données --- 
$conn = new mysqli("localhost", "u498346438_calculrem", "Calculrem1", "u498346438_calculrem"); 
if ($conn->connect_error) die("Erreur DB : " . $conn->connect_error); 
$conn->set_charset("utf8mb4"); 

/* === Fonction de bind automatique === */ 
function stmt_bind_auto($stmt, ...$vars) { 
    if (empty($vars)) return; 
    $types = ''; 
    foreach ($vars as $v) { 
        $types .= match (gettype($v)) { 
            'integer' => 'i', 
            'double' => 'd', 
            default => 's' 
        }; 
    } 
    $stmt->bind_param($types, ...$vars); 
} 

/* === Initialisation du panier === */ 
if (!isset($_SESSION['panier'])) $_SESSION['panier'] = []; 
$msg = ''; 
$ticket_ref = null; 

/* === Validation de la vente === */ 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['valider_vente'])) { 
    if (empty($_SESSION['panier'])) { 
        $msg = "⚠️ Aucun article dans le panier."; 
    } else { 
        $mode_paiement = $_POST['mode_paiement']; 
        $client_nom = trim($_POST['client_nom']); 
        $client_tel = trim($_POST['client_tel']); 
        $ticket_ref = 'POS-' . date('Ymd-His') . '-' . strtoupper(bin2hex(random_bytes(2))); 
        $total = 0; 
        $vendeur = $_SESSION['username'] ?? 'Inconnu'; 

        foreach ($_SESSION['panier'] as $item) { 
            $ptotal = $item['prix'] * $item['quantite']; 
            $total += $ptotal; 

            // Enregistrement de la vente 
            $stmt = $conn->prepare(" 
                INSERT INTO ventes (ref_vente, produit_ref, designation, quantite, prix_unitaire, prix_total, mode_paiement, client_nom, client_tel, vendeur) 
                VALUES (?,?,?,?,?,?,?,?,?,?) 
            "); 
            stmt_bind_auto($stmt, $ticket_ref, $item['reference'], $item['designation'], $item['quantite'], $item['prix'], $ptotal, $mode_paiement, $client_nom, $client_tel, $vendeur); 
            $stmt->execute(); 

            // Décrémentation du stock 
            $update = $conn->prepare(" 
                UPDATE stock_articles SET quantite = GREATEST(quantite - ?, 0) WHERE reference = ? 
            "); 
            stmt_bind_auto($update, $item['quantite'], $item['reference']); 
            $update->execute(); 
        } 

        $msg = "✅ Vente enregistrée avec succès (Total : " . number_format($total, 2, ",", " ") . " €)"; 
        $_SESSION['panier'] = []; 
    } 
} 

/* === Ajout d'article au panier === */ 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter_article'])) { 
    $ref = trim($_POST['produit_ref']); 
    $qte = max(1, (int)$_POST['quantite']); 

    if ($ref !== '') { 
        $stmt = $conn->prepare(" 
            SELECT reference, ean, designation, prix_vente, quantite 
            FROM stock_articles 
            WHERE reference=? OR ean=? 
            LIMIT 1 
        "); 
        stmt_bind_auto($stmt, $ref, $ref); 
        $stmt->execute(); 
        $res = $stmt->get_result(); 

        if ($prod = $res->fetch_assoc()) { 
            if ($prod['quantite'] >= $qte) { 
                $_SESSION['panier'][] = [ 
                    'reference' => $prod['reference'], 
                    'designation' => $prod['designation'], 
                    'prix' => (float)$prod['prix_vente'], 
                    'quantite' => $qte 
                ]; 
                $msg = "🧾 Article ajouté : {$prod['designation']}"; 
            } else { 
                $msg = "⚠️ Stock insuffisant pour {$prod['designation']} (dispo : {$prod['quantite']})"; 
            } 
        } else { 
            $msg = "❌ Produit introuvable pour le code : {$ref}"; 
        } 
    } 
} 

/* === Suppression d'article du panier === */ 
if (isset($_GET['del'])) { 
    unset($_SESSION['panier'][(int)$_GET['del']]); 
    $_SESSION['panier'] = array_values($_SESSION['panier']); 
} 
?> 

<!doctype html> 
<html lang="fr"> 
<head> 
<meta charset="utf-8"> 
<title>🛒 Point de Vente - R.E.Mobiles</title> 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet"> 
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script> 

<style> 
body { background: radial-gradient(circle at top left, #0a0a0a, #1a1a1a); color: #fff; font-family: "Poppins", sans-serif; } 
h2 { color: #0dcaf0; text-transform: uppercase; font-weight: 800; letter-spacing: .5px; margin-bottom: 1.5rem; } 
.card { background: rgba(20,20,20,0.9); border: 1px solid rgba(13,202,240,0.25); border-radius: 16px; box-shadow: 0 0 25px rgba(13,202,240,0.15); } 
label { color: #bfeaff; font-weight: 600; } 
.form-control, .form-select { background: #111 !important; color: #fff !important; border: 1px solid rgba(13,202,240,0.25); border-radius: 10px; } 
.form-control::placeholder { color: #888 !important; opacity: 1; } 
.form-control:focus, .form-select:focus { border-color: #0dcaf0; box-shadow: 0 0 0 0.2rem rgba(13,202,240,.25); } 
.btn-gradient { background: linear-gradient(90deg,#0d6efd,#0dcaf0); color: #fff; font-weight: 700; border: none; border-radius: 10px; transition: all .3s ease; } 
.btn-gradient:hover { transform: scale(1.05); box-shadow: 0 0 15px rgba(13,202,240,.5); } 
.alert-info { background: rgba(13,202,240,0.15); border: 1px solid #0dcaf0; color: #0dcaf0; font-weight: 600; text-align: center; } 
.autocomplete-results { position: absolute; top: 100%; left: 0; right: 0; background: rgba(25,28,32,0.97); border: 1px solid rgba(13,202,240,0.5); border-radius: 10px; box-shadow: 0 8px 20px rgba(13,202,240,0.25); display: none; z-index: 3000; max-height: 320px; overflow-y: auto; backdrop-filter: blur(6px); } 
.autocomplete-item { padding: 10px 14px; cursor: pointer; border-bottom: 1px solid rgba(255,255,255,0.1); color: #e8f8ff; font-size: 0.95rem; transition: all 0.2s ease; } 
.autocomplete-item small { display: block; color: #8fd4ff; font-size: 0.8rem; } 
.autocomplete-item:hover { background: linear-gradient(90deg, rgba(13,202,240,0.25), rgba(13,110,253,0.25)); color: #fff; transform: scale(1.01); } 
iframe.ticket { width: 100%; height: 520px; border-radius: 14px; border: 2px solid rgba(13,202,240,0.4); background: #111; margin-top: 25px; } 
</style> 

<script> 
$(function(){ 
    const input = $('#produit_ref'); 
    const resultsBox = $('<div class="autocomplete-results"></div>').insertAfter(input); 
    let timer; 

    // --- Recherche en direct --- 
    input.on('input', function(){ 
        clearTimeout(timer); 
        const query = $(this).val().trim(); 
        if(query.length < 2){ resultsBox.hide(); return; } 
        timer = setTimeout(() => { 
            $.getJSON('ajax_search_stock.php', {q: query}, function(data){ 
                resultsBox.empty(); 
                if(data.length === 0){ resultsBox.hide(); return; } 
                data.forEach(item => { 
                    const dispo = item.quantite > 0 ? '✅ En stock ('+item.quantite+')' : '❌ Rupture'; 
                    const html = `<div class="autocomplete-item"> 
                        <strong>${item.reference}</strong> — ${item.designation}<br> 
                        <small>${item.marque||''} ${item.modele||''} ${item.etat||''} | ${item.prix_vente} € | ${dispo}</small> 
                    </div>`; 
                    const div = $(html).data('item', item); 
                    resultsBox.append(div); 
                }); 
                resultsBox.fadeIn(150); 
            }); 
        }, 200); 
    }); 

    // --- Clic sur un résultat --- 
    resultsBox.on('click','.autocomplete-item',function(){ 
        const item = $(this).data('item'); 
        input.val(item.reference); 
        resultsBox.fadeOut(150); 
    }); 

    // --- Fermeture si clic ailleurs --- 
    $(document).on('click',function(e){ 
        if(!$(e.target).closest('.autocomplete-results, #produit_ref').length){ 
            resultsBox.fadeOut(100); 
        } 
    }); 

    // --- Scan automatique (lecteur EAN) --- 
    input.on('keypress', function(e){ 
        if(e.which === 13){ 
            e.preventDefault(); 
            const code = input.val().trim(); 
            if(code.length > 3){ 
                $.post('', { ajouter_article: 1, produit_ref: code, quantite: 1 }, function(){ 
                    location.reload(); 
                }); 
            } 
        } 
    }); 
}); 
</script> 
</head> 

<body> 
<div class="container py-4"> 
<?php include 'header.php'; ?> 
<h2 class="text-center fw-bold"> <i class="bi bi-cart-check"></i> Point de Vente - R.E.Mobiles </h2> 
<?php if ($msg): ?> 
<div class="alert alert-info"><?= htmlspecialchars($msg) ?></div> 
<?php endif; ?> 

<!-- 🔍 Recherche / ajout produit --> 
<form method="POST" class="card p-4 mb-4"> 
<h5 class="text-info fw-bold"> <i class="bi bi-upc-scan"></i> Scanner / Rechercher une pièce </h5> 
<div class="row g-3 align-items-end mt-2"> 
<div class="col-md-5 position-relative"> 
<label>Code EAN / Référence / Désignation</label> 
<input type="text" name="produit_ref" id="produit_ref" class="form-control" placeholder="Scannez ou tapez ici..." autocomplete="off" autofocus required> 
</div> 
<div class="col-md-2"> 
<label>Quantité</label> 
<input type="number" name="quantite" value="1" min="1" class="form-control"> 
</div> 
<div class="col-md-3 text-end"> 
<button type="submit" name="ajouter_article" class="btn btn-gradient w-100"> ➕ Ajouter </button> 
</div> 
</div> 
</form> 

<!-- 🧾 Panier --> 
<div class="card p-4 mb-4"> 
<h5 class="text-info fw-bold"> <i class="bi bi-bag-check"></i> Panier en cours </h5> 
<?php if (empty($_SESSION['panier'])): ?> 
<p class="text-muted mt-3">Aucun article ajouté.</p> 
<?php else: ?> 
<div class="table-responsive mt-3"> 
<table class="table table-dark table-striped align-middle text-center"> 
<thead> 
<tr> <th>#</th><th>Référence</th><th>Désignation</th><th>Qté</th> <th>PU</th><th>Total</th><th>❌</th> </tr> 
</thead> 
<tbody> 
<?php $total=0;$i=0; foreach($_SESSION['panier'] as $item): $t=$item['prix']*$item['quantite']; $total+=$t; ?> 
<tr> 
<td><?=++$i?></td> 
<td><?=htmlspecialchars($item['reference'])?></td> 
<td class="text-start"><?=htmlspecialchars($item['designation'])?></td> 
<td><?=$item['quantite']?></td> 
<td><?=number_format($item['prix'],2,',',' ')?></td> 
<td class="fw-bold text-success"><?=number_format($t,2,',',' ')?></td> 
<td><a href="?del=<?=$i-1?>" class="btn btn-danger btn-sm">✖</a></td> 
</tr> 
<?php endforeach; ?> 
</tbody> 
<tfoot> 
<tr> <th colspan="5" class="text-end">TOTAL (€)</th> <th colspan="2" class="text-warning fs-5"><?=number_format($total,2,',',' ')?></th> </tr> 
</tfoot> 
</table> 
</div> 
<?php endif; ?> 
</div> 

<!-- 💳 Validation --> 
<form method="POST" class="card p-4 mb-4"> 
<h5 class="text-info fw-bold"> <i class="bi bi-credit-card"></i> Finaliser la vente </h5> 
<div class="row g-3 mt-2"> 
<div class="col-md-4"> 
<label>Mode de paiement</label> 
<select name="mode_paiement" class="form-select" required> 
<option value="Espèces">Espèces</option> 
<option value="Carte Bancaire">Carte Bancaire</option> 
<option value="Virement">Virement</option> 
<option value="Autre">Autre</option> 
</select> 
</div> 

<div class="col-md-4 position-relative">
  <label>Nom du client (facultatif)</label>
  <input type="text" id="client_nom" name="client_nom" class="form-control" placeholder="Tapez le nom du client..." autocomplete="off">
  <div id="suggestions" class="list-group position-absolute w-100"></div>
</div>

<div class="col-md-4"> 
<label>Téléphone client (facultatif)</label> 
<input type="text" name="client_tel" class="form-control" placeholder="Ex : +594 694 12 34 56"> 
</div> 
</div> 
<div class="text-center mt-4"> 
<button type="submit" name="valider_vente" class="btn btn-gradient px-5 py-2 fw-bold fs-5"> 💾 Valider la vente </button> 
</div> 
</form> 

<?php if ($ticket_ref): ?> 
<iframe src="ticket_pos.php?ref=<?=urlencode($ticket_ref)?>" class="ticket"></iframe> 
<?php endif; ?> 
</div> 

<?php if ($ticket_ref): ?> 
<iframe src="ticket_pos.php?ref=<?=urlencode($ticket_ref)?>" class="ticket"></iframe> 
<?php endif; ?> 
</div>

<!-- 🔍 Autocomplétion clients -->
<script>
document.getElementById("client_nom").addEventListener("input", function() {
  const q = this.value.trim();
  const box = document.getElementById("suggestions");
  box.innerHTML = "";
  if (q.length < 2) return;
  fetch("clients_autocomplete.php?q=" + encodeURIComponent(q))
    .then(res => res.json())
    .then(data => {
      box.innerHTML = "";
      data.forEach(c => {
        const div = document.createElement("div");
        div.className = "list-group-item list-group-item-action bg-dark text-white";
        div.textContent = c.nom + " (" + c.telephone + ")";
        div.onclick = () => {
          document.getElementById("client_nom").value = c.nom;
          const tel = document.querySelector("input[name='client_tel']");
          if (tel && c.telephone) tel.value = c.telephone;
          box.innerHTML = "";
        };
        box.appendChild(div);
      });
    });
});
</script>

</body> 
</html>


</body> 
</html>
